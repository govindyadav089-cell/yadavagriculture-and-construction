Updated address: At Thethetanger, PO Brangjor, Tah. Kunkuri, Dist. Jashpur, Chhattisgarh
Upload the updated index.html to the existing GitHub repository and replace the old file.
